﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet_Script : MonoBehaviour
{

    public int damage = 5;

    [SerializeField]
    private float Speed;

    [SerializeField]
    [Tooltip("How long bullets will last until automatically destroyed")]
    private float bulletDuration = 20;

    [SerializeField]
    private GameObject Explosion;

    // Start is called before the first frame update
    void Start()
    {
        Destroy(gameObject, bulletDuration);
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += transform.forward * Speed * Time.deltaTime;
    }


    void OnCollisionEnter(Collision collision)
    {
        ContactPoint contact = collision.contacts[0];

        Instantiate(Explosion, contact.point, Quaternion.identity);

        Destroy(gameObject);
    }
}
