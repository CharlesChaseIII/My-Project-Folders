﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinScript2 : MonoBehaviour
{
    public static int CoinCount = 0;

    // Start is called before the first frame update
    void Start()
    {
        ++CoinCount;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(0, 0, 90 * Time.deltaTime);
    }

    void OnTriggerEnter(Collider Col)
    {
        CoinTracker Tracker = Col.gameObject.GetComponent<CoinTracker>();
        if(Col.CompareTag("Player"))
        {
            Col.GetComponent<CoinTracker>().points++;

            Destroy(gameObject);
        }
    }

    void OnDestroy()
    {
        --CoinCount;

        if (CoinCount <= 0)
        {
            //if all coins are collected YOU WIN!!!

            GameObject Timer = GameObject.Find("Timer");
            Destroy(Timer);

            GameObject[] FireworkSystems = GameObject.FindGameObjectsWithTag("FireWorks");

            foreach (GameObject GO in FireworkSystems)

                GO.GetComponent<ParticleSystem>().Play();

            LevelManager load = GameObject.Find("LevelManager").GetComponent<LevelManager>();
            load.LoadLevel("WinScene");

        }
    }
}
