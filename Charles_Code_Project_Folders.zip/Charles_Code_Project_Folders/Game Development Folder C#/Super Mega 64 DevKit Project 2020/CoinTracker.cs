﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinTracker : MonoBehaviour
{
    public int points = 0;

    public int AmountOfCoins;

    //CoinScript2 Coins;

    // Use this for initialization
    void Start()
    {
        //Coins = GetComponent<CoinScript2>();
    }

    // Update is called once per frame
    void Update()
    {

    }



    private void OnGUI()
    {
        GUI.color = Color.cyan;
        var centeredStyle = GUI.skin.GetStyle("Label");
        centeredStyle.alignment = TextAnchor.UpperCenter;
        centeredStyle.fontSize = 20;
        GUI.Label(new Rect(Screen.width / 2 - 50, 0, 100, 50), "Coins: " + points 
            + "/" + AmountOfCoins, centeredStyle);
    }


}

