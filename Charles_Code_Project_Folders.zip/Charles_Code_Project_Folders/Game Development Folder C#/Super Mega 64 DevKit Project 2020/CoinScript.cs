﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinScript : MonoBehaviour
{
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(0, 0, 90 * Time.deltaTime);
    }

    void LoadNextLevel()
    {
       
    }

    private void OnTriggerEnter(Collider other)
    {
        CoinTracker Tracker = other.gameObject.GetComponent<CoinTracker>();
        if (other.name == "Player")

            //adds 1 to point
            other.GetComponent<CoinTracker>().points++;

        //destroys object after colliding with it
        Destroy(gameObject);

        
    }


}


