﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoDestructScript : MonoBehaviour
{
    //The time it takes for the game object to self-destruct
    [SerializeField]
    private float DestructionTime = 5;

    // Start is called before the first frame update
    void Start()
    {
        Destroy(gameObject, DestructionTime);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
