﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FSM : MonoBehaviour
{
    //Tracking the player's position.
    [SerializeField]
    protected Transform PlayerTransform;

    //The next destination of the enemy npc.
    [SerializeField]
    protected Vector3 destPos;

    //BulletShoot Rate
    public float shootRate;

    public float elaspedTime;

    //List of waypoints we want enemy to travel to.
    [SerializeField]
    protected GameObject[] WaypointList;

    
    public Transform GunPosition { get; set; }

    public Transform BulletSpawnPoint { get; set; }

    [SerializeField]
    private float Speed;

    protected virtual void Initialize() { }

    protected virtual void FSMUpdate() { }

    protected virtual void FSMFixedUpdate() { }

    // Start is called before the first frame update
    void Start()
    {
        Initialize();
    }

    // Update is called once per frame
    void Update()
    {
        FSMUpdate();
    }

    void FixedUpdate()
    {
        FSMFixedUpdate();
    }
}
