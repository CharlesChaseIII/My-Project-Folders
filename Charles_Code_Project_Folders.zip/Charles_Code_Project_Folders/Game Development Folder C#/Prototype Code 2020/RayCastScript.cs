﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RayCastScript : MonoBehaviour
{
    Ray ray;

    RaycastHit hitRay;

    public LayerMask mask;
    
   

    // Update is called once per frame
    void Update()
    {
        
        Ray ray = new Ray(transform.position, transform.forward);

        if (Physics.Raycast(ray, out hitRay, 100, mask, QueryTriggerInteraction.Ignore))
        {
            print(hitRay.collider.gameObject.name);

            Destroy(hitRay.transform.gameObject);

            Debug.DrawLine(ray.origin, hitRay.point, Color.red);
        }
        
        else
        {
            Debug.DrawLine(ray.origin, ray.direction * 100, Color.blue);
        }




    }
}
