﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleFiniteStateMachine : FSM
{
    public enum FSM_States
    {
        None,

        Patrol,

        Chase,

        Attack,

        Dead,
    }

    public AudioClip sound;

    public AudioClip sound2;

    public AudioSource soundPlayer;

    public Animator anim;

    [SerializeField]
    public int health;

    //The state we want to go next. "cur" means current.
    [SerializeField]
    private FSM_States curState;

    //The speed we want set at this time.
    [SerializeField]
    private float curSpeed;

    //The rotation we set at this time.
  
    private float curRotationSpeed;

    //When the player dies
    [SerializeField]
    private bool EnemyIsDead;

    [SerializeField]
    private bool ShootProjectile;

    //The bullet Object.
    [SerializeField]
    private GameObject bullet;

    new private Rigidbody rigidbody;

    void Awake()
    {
        anim = GetComponent<Animator>();
    }

    protected override void Initialize()
    {
        curState = FSM_States.Patrol;

        curSpeed = 5f;

        curRotationSpeed = 2.0f;

        EnemyIsDead = false;

        elaspedTime = 0.0f;

        shootRate = 1f;

        health = 1;

        //WaypointList = GameObject.FindGameObjectsWithTag("WandarPoints");

        FindNextPoint();

        //Find the target enemy with tag (Player)
        GameObject objPlayer = GameObject.FindGameObjectWithTag("Player");

        rigidbody = GetComponent<Rigidbody>();

        anim = GetComponent<Animator>();
        
        PlayerTransform = objPlayer.transform;

        if (!PlayerTransform)
        {
            print("Please player does not exist... Please add one/n" +
                "with tag named 'Player' Tag");
        }

        GunPosition = gameObject.transform.GetChild(0).transform;

        BulletSpawnPoint = GunPosition.transform.GetChild(0).transform;
    }

    protected override void FSMUpdate()
    {
        switch (curState)
        {
            case FSM_States.Patrol:
                soundPlayer.clip = sound2;

                soundPlayer.Play();
                anim.SetBool("IsPatrolling", true);
                anim.SetBool("IsAttacking", false);
                anim.SetBool("IsChasing", false);
                anim.SetBool("IsDead", false);
                UpdatePatrolState(); break;

            case FSM_States.Chase:
                soundPlayer.clip = sound2;

                soundPlayer.Play();
                anim.SetBool("IsChasing", true);
                anim.SetBool("IsPatrolling", false);
                anim.SetBool("IsAttacking", false);
                anim.SetBool("IsDead", false);
                UpdateChaseState();  break;

            case FSM_States.Attack:
                anim.SetBool("IsAttacking", true);
                anim.SetBool("IsChasing", false);
                anim.SetBool("IsPatrolling", false);
                anim.SetBool("IsDead", false);
                UpdateAttackState();  break;

            case FSM_States.Dead:
                anim.SetBool("IsDead", true);
                anim.SetBool("IsAttacking", false);
                anim.SetBool("IsChasing", false);
                anim.SetBool("IsPatrolling", false);
                UpdateDeadState(); break;

        }

        //Update the time.
        elaspedTime += Time.deltaTime;

        //Go to dead state when no health is left.
        if (health <= 0)
        {
            curState = FSM_States.Dead;
        }
    }

    protected void UpdatePatrolState()
    {
        //destPos.y = transform.position.y;
        //Find another random patrol point if the current point is reached.
        //100.0f
        if (Vector3.Distance(transform.position, destPos) <= 10.0f)
        {
            print("Reached your current destination/n" +
                "calculating the next point");

            FindNextPoint();
        }
        //300.0f
        else if (Vector3.Distance(transform.position, PlayerTransform.position) <= 11.0f)
        {
            print("Switch to Chase Position");
            curState = FSM_States.Chase;
            //anim.SetBool("IsChasing", true);
        }

        //Rotate to the target point
        Quaternion TargetRotation = Quaternion.LookRotation(destPos - transform.position);

        transform.rotation = Quaternion.Slerp(transform.rotation, TargetRotation, curRotationSpeed
            * Time.deltaTime);

        //Go Forward
        transform.Translate(Vector3.forward * curSpeed * Time.deltaTime);
    }

    protected void FindNextPoint()

    {
        print("Finding next point");

        int rndIndex = Random.Range(0, WaypointList.Length);

        float rndRadius = 10.0f;

        Vector3 rndPosition = Vector3.zero;

        destPos = WaypointList[rndIndex].transform.position + rndPosition;

         //Keeps The enemy position from going into the air 
        //destPos.y = PlayerTransform.position.y;


        //Check Range to decide the random point as the same as before

        if (IsInCurrentRange(destPos))
        {
            rndPosition = new Vector3(Random.Range(-rndRadius, rndRadius), 0.0f,
            Random.Range(-rndRadius,rndRadius));

            destPos = WaypointList[rndIndex].transform.position + rndPosition;
        }
    }

    protected bool IsInCurrentRange(Vector3 pos)
    {
        float xPos = Mathf.Abs(pos.x - transform.position.x);

        float zPos = Mathf.Abs(pos.z - transform.position.z);

        if (xPos <= 50 && zPos <= 50)
            return true;

            return false;
    }

    protected void UpdateChaseState()
    {
        //anim.SetBool("IsPatrolling", false);
        //destPos.y = PlayerTransform.position.y;

        //Set the target position to the player position.
        destPos = PlayerTransform.position;

        //Check the distance of the player, when the distance is near transition to attack mode.
        float dist = Vector3.Distance(transform.position, PlayerTransform.position);
        //200.0f
        if (dist <= 20.0f)
        {
            curState = FSM_States.Attack;
           // anim.SetBool("IsAttacking", true);
        }

        //Go back to patrol if player goes off too far.
        //300.0f
        else if (dist >= 30.0f)
        {
            curState = FSM_States.Patrol;
        }

        //Go Forward
        transform.Translate(Vector3.forward * Time.deltaTime * curSpeed);
    }

    protected void UpdateAttackState()
    {
       // anim.SetBool("IsPatrolling", false);

        destPos.y = PlayerTransform.position.y;
        
        //Set the target position to the player position.
        destPos = PlayerTransform.position;

        //Check distance with player.
        float dist = Vector3.Distance(transform.position, PlayerTransform.position);

        // Attack player when player is close enough.
        //(dist >= 200.0f && dist < 300.0f)
        if (dist >= 5.0f && dist < 10.0f)
        {
            //Rotate to the target point
            Quaternion TargetRotation = Quaternion.LookRotation(destPos - transform.position);

            transform.rotation = Quaternion.Slerp(transform.rotation, TargetRotation,
            Time.deltaTime * curRotationSpeed);

            //Go forward
            transform.Translate(Vector3.forward * Time.deltaTime * curSpeed);

            curState = FSM_States.Attack;
            //anim.SetBool("IsAttacking", true);
        }
        //(dist >= 300)
        else if (dist >= 30.0f)
        {
            curState = FSM_States.Patrol;
        }

        //Always turn the turret towards the player
        Quaternion GunPositionRotation = Quaternion.LookRotation(destPos - GunPosition.position);

        GunPosition.rotation = Quaternion.Slerp(GunPosition.rotation, GunPositionRotation,
            Time.deltaTime * curRotationSpeed);

        ShootBullet();

    }

    void ShootBullet()
    {
        if (elaspedTime >= shootRate)
        {
            Instantiate(bullet, BulletSpawnPoint.position, BulletSpawnPoint.rotation);

            elaspedTime = 0.0f;

            soundPlayer.clip = sound;

            soundPlayer.Play();
        }

    }

    protected void UpdateDeadState()
    {
        //Show the dead animation with some physics effects
        if (!EnemyIsDead)
        {
            EnemyIsDead = true;
            //anim.SetBool("IsDead", EnemyIsDead);
            Explode();
        }

    }

    protected void Explode()
    {
        float rndX = Random.Range(10.0f, 30.0f);

        float rndZ = Random.Range(10.0f, 30.0f);

        for (int i = 0; i < 3; i++)
        {
            rigidbody.AddExplosionForce(10000.0f, transform.position - new Vector3(rndX, 10.0f,
                rndZ), 40.0f, 10.0f);

            rigidbody.velocity = transform.TransformDirection(new Vector3(rndX, 20.0f, rndZ));
        }

        Destroy(gameObject, 1.5f);
    }

    private void OnCollisionEnter(Collision collision)
    {
        //Reduce health
        if (collision.gameObject.tag == "Ropeshot") {

            health -= collision.gameObject.GetComponent<RopeshotAttack>().ropeshotDamage;
            Debug.Log("I have been attacked");
        }
    }


}
