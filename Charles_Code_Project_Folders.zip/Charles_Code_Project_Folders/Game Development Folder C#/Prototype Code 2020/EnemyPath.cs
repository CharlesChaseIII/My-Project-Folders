﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyPath : MonoBehaviour
{

    public float speed;

    public Transform Player;

    public Transform[] waypoints;

    public Transform currentWayPoints;

    public int currentIndex;

    public float minDistance = 0.5f;

    public float maxDistance = 5f;

    Rigidbody rb;

    public float playerDistance = 5f;

    public float playerMinDistance = 0.1f;

    public Vector3 offset = new Vector3 (0.1f, 0.1f, 0.1f);

    public Transform offsetPosition;

    // Start is called before the first frame update
    void Start()
    {
        offsetPosition = Player.transform;

        rb = GetComponent<Rigidbody>();

        currentWayPoints = waypoints[0];

        currentIndex = 0;

        
    }

    // Update is called once per frame
    void Update()
    {
        MoveTowardWaypoint();
        if (Vector3.Distance(currentWayPoints.transform.position, transform.position) < minDistance)
        {

            if (Vector3.Distance(transform.position, Player.transform.position)
                < playerDistance)
            {

                if (Vector3.Distance(transform.position,
                    Player.transform.position) > playerMinDistance)
                {

                    currentWayPoints = Player.transform;

                }

                else
                {

                    offsetPosition.position = Player.transform.position + offset;

                    currentWayPoints = offsetPosition;

                }
            }

            else
            {
                currentIndex++;
                if (currentIndex > waypoints.Length - 1)
                {
                    currentIndex = 0;

                }
                currentWayPoints = waypoints[currentIndex];
            }

        }
    }

    void MoveTowardWaypoint()
    {
        Vector3 OtherDirection = currentWayPoints.transform.position;

        OtherDirection.y = transform.position.y;

        currentWayPoints.transform.position = OtherDirection;

        Vector3 Direction = OtherDirection - transform.position;

        Vector3 MoveVector = Direction.normalized * speed * Time.deltaTime;

        transform.position += MoveVector;

        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(Direction), 4 * Time.deltaTime);
    }


    
}
