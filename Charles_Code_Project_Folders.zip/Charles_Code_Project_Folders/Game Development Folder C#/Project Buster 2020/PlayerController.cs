﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public int speed;

    public int health;

    public int damage;

    public int projectile;

    public Animator myAnimator;

    public Collider2D myCollider;

    public Rigidbody2D rB;

    public int attackdmg;

    public int jumpForce;

    Vector2 playerSpeed;


    // Start is called before the first frame update
    void Start()
    {
        rB = GetComponent<Rigidbody2D>();

        myCollider = GetComponent<Collider2D>();

        myAnimator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        Movement();

        Jump();
    }

    

    void Movement()
    {
        // gives input control to move left and right on x axis.
        float PlayerHorizontal = Input.GetAxis("Horizontal");

        //We are setting the speed of the player.
        Vector2 playerSpeed = new Vector2(PlayerHorizontal * speed, rB.velocity.y);

        //We are assigning the speed of the player to the speed of the rigidbody so it is part of the physics.
        rB.velocity = playerSpeed;


        /*if (Input.GetButtonDown("Jump")) 
        {
            vec = Vector2.up * speed * jumpforce;
        }

        rB.AddForce(vec);*/

    }

    void FlipSprite()
    {
        bool PlayerHasHorizontalSpeed = Mathf.Abs(rB.velocity.x) > Mathf.Epsilon;

        if (PlayerHasHorizontalSpeed)
        {

            transform.localScale = new Vector2(Mathf.Sign(rB.velocity.x), 1f);

        }
    }

    public void Jump()
    {
        
        if (!myCollider.IsTouchingLayers(LayerMask.GetMask("Ground")))

        {
            return;
        }

        if (Input.GetButtonDown("Jump"))
        {
            //Gives speed to the player's jump and how much force they fly up with.
            Vector2 addedJumpSpeed = new Vector2(jumpForce, 20f);

            //adds the speed of the player to the jump.
            rB.velocity += addedJumpSpeed;

        }
    }

    /*void Collider.OnCollisionEnter2D(myCollider)
    {


    }*/

}


