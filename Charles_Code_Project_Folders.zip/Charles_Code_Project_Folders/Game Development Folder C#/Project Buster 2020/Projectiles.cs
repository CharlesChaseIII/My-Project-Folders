﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectiles : MonoBehaviour
{
    public GameObject Projectile;
    public float ProjectileSpeed;
    public float damage;
    //public float health;
    public float shotsPerSecond = 0.5f;
    

    void Start()
    {
       
    }

    void Update()
    {
        //i stop this function 
        float load = shotsPerSecond * Time.deltaTime;

        if (Random.value > load)
        {
            Fire();
        }
        
    }

    public float Getdamage()
    {
        return damage;
    }


    public void Hit()
    {
        Destroy(gameObject);
    }

    public void Fire()
    {
        GameObject laser = Instantiate(Projectile, transform.position, Quaternion.identity) as GameObject;
        laser.GetComponent<Rigidbody2D>().velocity = new Vector2(3, -ProjectileSpeed);
    }
    
}