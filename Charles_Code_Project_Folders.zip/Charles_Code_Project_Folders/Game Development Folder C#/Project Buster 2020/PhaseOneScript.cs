﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhaseOneScript : MonoBehaviour
{
    public float damage;
    public float MaxHealth;
    public float CurrHealth;
    //public float maxhealth = 100f;
    float min = 1;
    float max = 6;
    public float probability;
    Animator anim;

    Transform offsetPosition;
    //variables for the waypoints in our system
    public Transform[] waypoints;
    public float minDistance = 0.1f;
    public float maxDistance = 5f;
    public float moveSpeed = 5f;

    //variables to target and follow the player

    public Transform player;

    //What the boss will follow. We apply the player to be the target so the boss will follow the player
    GameObject target;

    //Here we make this variable so we can lock the boss on the y axis so the sprite does not flip in the third dimension.
    Vector3 targetPosition;

    //We make this variable so we can initialize it with the value of targetPosition and so targetPosition can pass through as a float value
    Transform targetPositionTransform;

    /*tracks the player if the enemy is within 5 units. 
    This can be randomized so some enemies with this same script can the follow the player at different ranges.*/

    public float playerDistance = 5f;
    public float playerMinDistance = 0.1f;
    public Vector3 offset = new Vector3(0.1f, 0.1f, 0.1f);

    //variables to track our progress
    public Transform currentWaypoint;
    public int currentIndex;
    Rigidbody2D BossRB;

    //variables of player object
    public WHC_playerControl s_WHC_playerControl;

    private SceneLevelManager sceneLvlManager;

    // Use this for initialization
    void Start()
    {
        sceneLvlManager = GameObject.Find("SceneLevelManager").GetComponent<SceneLevelManager>();
        s_WHC_playerControl = GameObject.FindGameObjectWithTag("Player").GetComponent<WHC_playerControl>();

        anim = GetComponent<Animator>();
        BossRB = GetComponent<Rigidbody2D>();
        target = GameObject.Find("Player");

        Vector3 targetPosition = new Vector3(transform.position.x, transform.position.y, player.transform.position.z);

        //intialize array and index
        currentWaypoint = waypoints[0];
        currentIndex = 0;
        offsetPosition = player.transform;

        //set the curr hp same as max hp
        CurrHealth = MaxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        CheckIfBossDie();
        BossKaratechop();
        ThunderAttack();
        //follow the path
        MoveTowardWaypoint();
        //check for minimum distance
        if (Vector3.Distance(currentWaypoint.transform.position, transform.position) < minDistance)
        {

            //If player is within range, follow that instead of path

            if (Vector3.Distance(player.transform.position, transform.position) < playerDistance)
            {
                if (Vector3.Distance(player.transform.position, transform.position) > playerMinDistance)
                {
                    /*Here we are transferring the value of targetPosition into 
                    targetPositionTransform so it passes as the same type currrent waypoint transform*/

                    /*targetPositionTransform.position = targetPosition;
                    currentWaypoint = targetPositionTransform;*/

                    currentWaypoint = player;


                }
                else
                {
                    //transferring the value of the postion of offset transform into the player postion + offset

                    //!!!!I got error on this
                    //offsetPosition.position = target.transform.position + offset;
                    //currentWaypoint = offsetPosition;
                }

            }
            else
            {
                ++currentIndex;
                //checking that we have not reached the end of the array
                if (currentIndex > waypoints.Length - 1)
                {
                    currentIndex = 0;
                }

                //setting the current waypoint to the next waypoint in the array
                currentWaypoint = waypoints[currentIndex];
            }
        }

    }
    
       

    
    //i dont think we need this function so just comment it
    void OnTriggerEnter2D(Collider2D collider)
    {
       
        Projectiles missile = collider.gameObject.GetComponent<Projectiles>();
        if (missile.tag == "Player")
        {
            CurrHealth -= missile.Getdamage();
            missile.Hit();
        }
        
    }

    public float Getdamage()
    {
        return damage;
    }

    void BossKaratechop()
    {
        probability = (Random.Range(min, max));
        if (probability < 3f) {

            playerDistance = 30;

            anim.SetBool("IsOpen", true);
        } else {

            anim.SetBool("IsOpen", false);
        }
    }

    void ThunderAttack()
    {
        probability = (Random.Range(min, max));
        if (probability >= 3f)
        {
            playerDistance = 40;

            anim.SetBool("Thunder", true);
        }
        else
        {

            anim.SetBool("Thunder",false);
        }
    }

    /*moves toward the waypoint, does not use or manipulate physics. 
    If you want to manipulate physics then add a rigidbody to the function.*/


    void MoveTowardWaypoint()
    {
        
        //direction we want to move toward
        Vector2 direction = currentWaypoint.transform.position - transform.position;
        Vector3 moveVector = direction.normalized * moveSpeed * Time.deltaTime;
        //adding the movement to our current position
        transform.position += moveVector;
        //makes sure we are facing the next waypoint
        //transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), 4 * Time.deltaTime);
    }

    //if get hit by the player projectile, run this function (this function will be called in the projectile script)
    public void DamagedByPlayer()
    {
        CurrHealth -= 10;
    }


    //go to next level if boss dies
    void CheckIfBossDie()
    {
        if (CurrHealth <= 0)
        {
            sceneLvlManager.LoadStage2();
        }
    }


}
