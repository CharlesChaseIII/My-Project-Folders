﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Turtle_Cutscenecc : MonoBehaviour {
    public Text text;
    public enum States
    {
        Scene_1, Scene_2
    };

    private States myState;

    public Button play_level;
    // Use this for initialization
    void Start ()
    {
        myState = States.Scene_1;
        play_level.gameObject.SetActive(false);
    }



    // Update is called once per frame
    void Update () {
        print(myState);
        if (myState == States.Scene_1) { Scene_1(); }

        else if (myState == States.Scene_2) { Scene_2(); }
    }

    void Scene_1()
    {
        text.text = "After removing all that plastic, the Cheasapeake begins to flow with more life." +
               "The Turtle sees the fruits of his efforts and has more determination than ever before." +
               "No time for breaks. I must keep going, thinks the turtle." +
               " Up ahead there is more plastic brewing but this time it is different." +
               " Suddenly a huge mass of platic forms.\n\n" +
                        "Press c to keep reading ";
        
         if (Input.GetKeyDown(KeyCode.C)) { myState = States.Scene_2; }
        

    }

    void Scene_2()
    {
        text.text = "It is a trash Island!" +
               " The Turtle is friends with the crabs and birds, " +
               "he does not want either trash or furry invadors ruining his home." +
               "It is up to you now, save Cheasapeake bay!\n\n";
        play_level.gameObject.SetActive(true);


    }

   

    public void play_level_now()
    {
        SceneManager.LoadScene("Level 3");
    }

    public void LoadNextLevel2()
    {
        SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex + 1);
    }

}
