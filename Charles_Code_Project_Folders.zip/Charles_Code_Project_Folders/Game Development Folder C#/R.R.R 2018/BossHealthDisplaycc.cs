﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BossHealthDisplaycc : MonoBehaviour {

    Text Healthtext;
    Boss_Behaviorcc boss;
    // Use this for initialization
    void Start()
    {
        Healthtext = GetComponent<Text>();
        boss = FindObjectOfType<Boss_Behaviorcc>();

    }

    // Update is called once per frame
    void Update()
    {
        Healthtext.text = boss.GetHealth().ToString();
    }
}