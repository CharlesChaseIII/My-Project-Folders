﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawnercc : MonoBehaviour {

    [SerializeField] List<WaveConfigurecc> waveConfigurecc;
    [SerializeField] int startingWave = 0;
    [SerializeField] bool looping = false;

    // Use this for initialization
    IEnumerator Start()
    {
        do
        {
            yield return StartCoroutine(SpawnAllWaves());
        }
        while (looping);
    }

    private IEnumerator SpawnAllWaves()
    {
        for (int waveIndex = startingWave; waveIndex < waveConfigurecc.Count; waveIndex++)
        {
            var currentWave = waveConfigurecc[waveIndex];
            yield return StartCoroutine(SpawnAllEnemiesInWave(currentWave));
        }
    }

    private IEnumerator SpawnAllEnemiesInWave(WaveConfigurecc waveConfigurecc)
    {
        for (int enemyCount = 0; enemyCount < waveConfigurecc.GetNumberOfEnemies(); enemyCount++)
        {
           var newEnemy = Instantiate(
                waveConfigurecc.GetEnemyPrefab(),
                waveConfigurecc.GetWaypoints()[0].transform.position,
                Quaternion.identity);
            newEnemy.GetComponent<Enemypathcc>().SetWaveConfigurecc(waveConfigurecc);
            yield return new WaitForSeconds(waveConfigurecc.GetTimeBetweenSpawns());
        }
    }
}
