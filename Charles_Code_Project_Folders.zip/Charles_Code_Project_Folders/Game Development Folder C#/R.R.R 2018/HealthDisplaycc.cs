﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthDisplaycc : MonoBehaviour {
    Text Healthtext;
    PlayerControllercc player;
	// Use this for initialization
	void Start () {
        Healthtext = GetComponent<Text>();
        player = FindObjectOfType<PlayerControllercc>();
        
    }
	
	// Update is called once per frame
	void Update () {
        Healthtext.text = player.GetHealth().ToString();
    }
}
