﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Scoredisplaycc : MonoBehaviour {
    Text Score;
    Game_Session GameSession;
	
    // Use this for initialization
	void Start () {
        
        Score = GetComponent<Text>();
        GameSession = FindObjectOfType<Game_Session>();
        
	}

    // Update is called once per frame
    void Update()
    {
        Score.text = GameSession.GetScore().ToString();
    }
    
	}

