﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;
public class PlayerControllercc : MonoBehaviour {
	public float speed = 15.0f;
	public GameObject projectile;
    public GameObject deathVFX;
    public AudioClip fireSound;
	public float padding = 1f;
	public float projectileSpeed = 10;
	public float firingRate = 0.2f;
	public float health = 250f;
    private PlayerHealthBarW healthBar;

    float xmin;
	float xmax;
    float ymin;
    float ymax;

    void OnTriggerEnter2D(Collider2D collider){
        Boss_Behaviorcc Touch = collider.gameObject.GetComponent<Boss_Behaviorcc>();
        if (Touch)
        {
            Debug.Log("Player Collided with Touch");
            health -= Touch.GetDamage();
            healthBar.SetHealth(health);
            GameObject explosion = Instantiate(deathVFX, transform.position, transform.rotation);

            if (health <= 0)
            {
                Die();
            }
        }
    
    Projectile missile = collider.gameObject.GetComponent<Projectile>();
		if(missile){
			Debug.Log ("Player Collided with missile");
			health -= missile.GetDamage();
			missile.Hit();
            healthBar.SetHealth(health);
            GameObject explosion = Instantiate(deathVFX, transform.position, transform.rotation);
            if (health <= 0) {
				Die();
			}
		}
	}


            void Die(){
		LevelManagercc man = GameObject.Find("LevelManager").GetComponent<LevelManagercc>();
		man.LoadLevel("GameOver");
		Destroy(gameObject);
	}

    public float GetHealth()
    {
        return health;
    }
	
	void Start(){
        //find the health bar in game
        healthBar = GameObject.FindObjectOfType<PlayerHealthBarW>();
        healthBar.SetHealth(health);
        //maxHealth = health;
        float distance = transform.position.z - Camera.main.transform.position.z;
        Vector3 leftmost = Camera.main.ViewportToWorldPoint(new Vector3(0, 0, 0));
        Vector3 rightmost = Camera.main.ViewportToWorldPoint(new Vector3(1, 0, 0));
        Vector3 downmost = Camera.main.ViewportToWorldPoint(new Vector3(0, 0, 0));
        Vector3 upmost = Camera.main.ViewportToWorldPoint(new Vector3(0, 1, 0));
        xmin = leftmost.x + padding;
        xmax = rightmost.x - padding;
        ymin = downmost.y + padding;
        ymax = upmost.y - padding;

    }
	
	void Fire(){
		GameObject beam = Instantiate(projectile, transform.position, Quaternion.identity) as GameObject;
		beam.GetComponent<Rigidbody2D>().velocity = new Vector3(0, projectileSpeed, 0);
		AudioSource.PlayClipAtPoint(fireSound, transform.position);
       
    }

	void Update () {
		if(Input.GetKeyDown(KeyCode.Space)){
			InvokeRepeating("Fire", 0.0001f, firingRate);
		}
		if(Input.GetKeyUp(KeyCode.Space)){
			CancelInvoke("Fire");
		}
        if (Input.GetKey(KeyCode.LeftArrow)) {
            transform.position += Vector3.left * speed * Time.deltaTime;
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.position += Vector3.right * speed * Time.deltaTime;
        }
        else if (Input.GetKey(KeyCode.UpArrow))
        {
            transform.position += Vector3.up * speed * Time.deltaTime;
        }
        else if (Input.GetKey(KeyCode.DownArrow))
           {
            transform.position += Vector3.down * speed * Time.deltaTime;
        }

        // restrict the player to the gamespace
        float newX = Mathf.Clamp(transform.position.x, xmin, xmax);
        float newY = Mathf.Clamp(transform.position.y, ymin, ymax);
        transform.position = new Vector3(newX, newY, transform.position.z);
    }



}
