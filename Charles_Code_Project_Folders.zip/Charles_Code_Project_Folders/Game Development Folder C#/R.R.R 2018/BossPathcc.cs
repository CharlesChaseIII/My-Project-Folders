﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public class BossPathcc : MonoBehaviour {

    
    [SerializeField] List<Transform> Waypoints;
    [SerializeField] float moveSpeed = 5f;
    int waypointIndex = 0;

    // Use this for initialization
    void Start()
    {
       
        transform.position = Waypoints[waypointIndex].transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        Move();
    }

    




    private void Move()
    {
        if (waypointIndex <= Waypoints.Count - 1)
        {
            var targetPosition = Waypoints[waypointIndex].transform.position;
            var movementThisFrame = moveSpeed * Time.deltaTime;
            transform.position = Vector3.MoveTowards
                (transform.position, targetPosition, movementThisFrame);

            if (transform.position == targetPosition)
            {
                waypointIndex++;
            }
        }
        else 
        {
            waypointIndex = 0;
        }
    



    }

}
