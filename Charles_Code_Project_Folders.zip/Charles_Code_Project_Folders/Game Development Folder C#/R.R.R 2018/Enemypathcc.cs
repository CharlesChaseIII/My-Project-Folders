﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemypathcc : MonoBehaviour {

    [SerializeField] WaveConfigurecc waveConfigcc;
    [SerializeField] List<Transform> Waypoints;
    int waypointIndex = 0;

    // Use this for initialization
    void Start () {
        Waypoints = waveConfigcc.GetWaypoints();
        transform.position = Waypoints[waypointIndex].transform.position;
	}

    // Update is called once per frame
    void Update()
    {
        Move();
    }

    public void SetWaveConfigurecc(WaveConfigurecc waveConfigurecc)
    {
        this.waveConfigcc = waveConfigcc;
    }

    


    private void Move() {
        if (waypointIndex <= Waypoints.Count - 1)
        {
            var targetPosition = Waypoints[waypointIndex].transform.position;
            var movementThisFrame = waveConfigcc.GetMoveSpeed() * Time.deltaTime;
            transform.position = Vector3.MoveTowards
                (transform.position, targetPosition, movementThisFrame);

            if (transform.position == targetPosition)
            {
                waypointIndex++;
            }
        }

        else
        {
            Destroy(gameObject);
        }
        
        
	}

}
