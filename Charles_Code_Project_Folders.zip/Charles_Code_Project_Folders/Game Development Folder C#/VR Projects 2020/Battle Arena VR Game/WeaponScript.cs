﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponScript : MonoBehaviour
{
    
    private ParticleSystem PS;

    // Use this for initialization
    void Awake()
    {
        PS = GetComponent<ParticleSystem>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            PS.Play();
            return;
        }

        if (Input.GetButtonUp("Fire1"))
        {
            PS.Stop();
            return;
        }
    }
}