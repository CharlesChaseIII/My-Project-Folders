﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageScript : MonoBehaviour
{
    public string TagDamage = "Enemy";
    private HealthScript ThisHealth = null;
    public float DamageAmount = 2f;

    private void Awake()
    {
        ThisHealth = GetComponent<HealthScript>();
    }

    private void OnParticleCollision(GameObject other)
    {
        if (!other.CompareTag(TagDamage)) return;
        ThisHealth.HealthPoints -= DamageAmount;
    }
}

