﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]

public class PlayerControllerVR : MonoBehaviour
{
    Ray ray;

    public KeyCode jumpKey;

    public KeyCode BulletKey;

    public float speed;

    public float health;

    public float damage;

    [Tooltip("Used to detect what surface to jump off of")] public float jumpForce;

    Rigidbody rB;

    Collider myCollider;

    RaycastHit hitRay;

    public LayerMask mask;

    public GameObject bullet;

    [Tooltip("Used to track how much cool down between each bullet")] public float elapsedTime;

    // Start is called before the first frame update
    void Start()
    {

     rB = GetComponent<Rigidbody>();

    }

    // Update is called once per frame
    void Update()
    {
        Movement();
        Jump();
        ShootProjectile();
    }

    void Movement()
    {
        if (Input.GetButtonDown("Fire1")) {
            transform.position = transform.position + Camera.main.transform.forward * speed
                * Time.deltaTime;
        }
        /*float moveHorizontal = Input.GetAxis("Horizontal");

        float moveVertical = Input.GetAxis("Vertical");

        Vector3 PlayerMovement = new Vector3(moveHorizontal * speed, 0, moveVertical * speed);

        rB.AddForce(PlayerMovement * speed);*/
       
    }

    void Jump()
    {
        Ray ray = new Ray(transform.position, -transform.up);

        if (Input.GetKeyDown(jumpKey))
        {
            

            if (Physics.Raycast(ray, out hitRay, .5f, mask, QueryTriggerInteraction.Ignore))
            {
                Vector3 Jump = new Vector3(0, 5 * jumpForce, 0);

                rB.velocity += Jump;

                print(hitRay.collider.gameObject.name);

                Debug.DrawLine(ray.origin, hitRay.point, Color.red, 100);

            }

            else
            {
                Debug.DrawLine(ray.origin, ray.direction, Color.blue, 100);
                return;
            }

        }
    }

    void ShootProjectile()
    {
        if (Input.GetKeyDown(BulletKey))
        {
            Instantiate(bullet, transform.position, transform.rotation);

            elapsedTime = 0.0f;
        }
        
    }

    void OnTriggerEnter(Collider Col)
    {
        /*if(Col.gameObject.tag == "Enemy")
        {
            health -= Col.gameObject.GetComponent<SimpleFiniteStateMachine>().damage;
        }

        if (Col.gameObject.tag == "Enemy2")
        {
            health -= Col.gameObject.GetComponent<SimpleFiniteStateMachine2>().damage;
        }*/

        if (Col.gameObject.tag == "Enemy Projectile")
        {
            health -= Col.gameObject.GetComponent<Bullet_Script>().damage;
            Debug.Log("Player is Damaged");
        }
    }

    private void OnGUI()
    {
        GUI.color = Color.green;
        var LeftStyle = GUI.skin.GetStyle("Label");
        LeftStyle.alignment = TextAnchor.UpperLeft;
        LeftStyle.fontSize = 20;
        GUI.Label(new Rect(Screen.width / 1.5f - 50, 0, 100, 50), "health: " + health
            , LeftStyle);
    }
}


