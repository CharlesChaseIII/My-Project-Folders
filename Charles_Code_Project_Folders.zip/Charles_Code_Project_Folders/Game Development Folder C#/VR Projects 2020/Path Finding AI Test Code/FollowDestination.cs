﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class FollowDestination : MonoBehaviour
{
    //Declaring and intializing the AI and its destination
    private NavMeshAgent ThisAgent = null;
    public Transform Destination = null;

    // Use this for initialization
    void Awake()
    {
        ThisAgent = GetComponent<NavMeshAgent>();
    }

    // Update is called once per frame
    void Update()
    {
        ThisAgent.SetDestination(Destination.position);
    }
}
