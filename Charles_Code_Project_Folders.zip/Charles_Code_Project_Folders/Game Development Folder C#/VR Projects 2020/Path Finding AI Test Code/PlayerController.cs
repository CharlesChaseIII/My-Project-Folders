﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]

public class PlayerController : MonoBehaviour
{
    Ray ray;

    public KeyCode jumpKey;

    public KeyCode BulletKey;

    public float speed;

    public float damage;

    [Tooltip("Used to detect what surface to jump off of")] public float jumpForce;

    Rigidbody rB;

    Collider myCollider;

    RaycastHit hitRay;

    public LayerMask mask;

    public GameObject bullet;

    [Tooltip("Used to track how much cool down between each bullet")] public float elapsedTime;

    // Start is called before the first frame update
    void Start()
    {

     rB = GetComponent<Rigidbody>();

    }

    // Update is called once per frame
    void Update()
    {
        Movement();
        Jump();
       
    }

    void Movement()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");

        float moveVertical = Input.GetAxis("Vertical");

        Vector3 PlayerMovement = new Vector3(moveHorizontal * speed, 0, moveVertical * speed);

        rB.AddForce(PlayerMovement * speed);
       
    }

    void Jump()
    {
        Ray ray = new Ray(transform.position, -transform.up);

        if (Input.GetKeyDown(jumpKey))
        {
            

            if (Physics.Raycast(ray, out hitRay, .5f, mask, QueryTriggerInteraction.Ignore))
            {
                Vector3 Jump = new Vector3(0, 5 * jumpForce, 0);

                rB.velocity += Jump;

                print(hitRay.collider.gameObject.name);

                Debug.DrawLine(ray.origin, hitRay.point, Color.red, 100);

            }

            else
            {
                Debug.DrawLine(ray.origin, ray.direction, Color.blue, 100);
                return;
            }

        }
    }

    

    

    
}


