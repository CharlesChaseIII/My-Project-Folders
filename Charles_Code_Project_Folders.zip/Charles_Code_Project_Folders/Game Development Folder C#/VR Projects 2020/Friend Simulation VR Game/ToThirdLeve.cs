﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ToThirdLeve : MonoBehaviour
{
    public string loadThisLevel;

    void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            LevelManager load = GameObject.Find("LevelManager").GetComponent<LevelManager>();

            load.LoadLevel("NightClub");
            Debug.Log("Next level loaded");
        }

    }


    public void NextLevelButton(int index)
    {
        SceneManager.LoadSceneAsync(index);
    }

    public void NextLevelButton(string levelName)
    {
        SceneManager.LoadSceneAsync(levelName);
    }
}