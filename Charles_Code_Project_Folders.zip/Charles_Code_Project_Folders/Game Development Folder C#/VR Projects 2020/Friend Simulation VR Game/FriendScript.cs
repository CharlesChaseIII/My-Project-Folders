﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FriendScript : MonoBehaviour
{
    public static int friendCount = 0;

    // Start is called before the first frame update
    void Start()
    {
        ++friendCount;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(0, 0, 90 * Time.deltaTime);
    }

    /*void OnTriggerEnter(Collider Col)
    {
        FriendTracker Tracker = Col.gameObject.GetComponent<FriendTracker>();
        if(Col.CompareTag("Player"))
        {
            Col.GetComponent<FriendTracker>().points++;

            Destroy(gameObject);
        }
    }*/

    public void GainFriend(GameObject Player)
    {
        FriendTracker Tracker = Player.gameObject.GetComponent<FriendTracker>();
        if (Player.CompareTag("Player"))
        {
            Player.GetComponent<FriendTracker>().points++;

            Destroy(gameObject);
        }
    }

    void OnDestroy()
    {
        --friendCount;

        if (friendCount <= 2)
        {
            GameObject[] FireworkSystems = GameObject.FindGameObjectsWithTag("FireWorks");

            foreach (GameObject GO in FireworkSystems)

                GO.GetComponent<ParticleSystem>().Play();
        }

        if (friendCount <= 0)
        {
            //if all coins are collected YOU WIN!!!

            GameObject Timer = GameObject.Find("Timer");
            Destroy(Timer);


            LevelManager load = GameObject.Find("LevelManager").GetComponent<LevelManager>();
            load.LoadLevel("Win_Scene");

        }
    }
}
