﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Timer : MonoBehaviour
{
    FriendTracker CoinGet;
    //Max Time to Complete Level In Seconds
    [Tooltip("Used to add or subtract time from the timer")] public float maxTime = 60f;

    //Countdown
    [SerializeField]
    [Tooltip("Used to the time counting down until 0, Once all coins are recieved +" +
        "Timer will be deleted")]
    private float CountDown = 0;


    // Start is called before the first frame update
    void Start()
    {
        CountDown = maxTime;
    }

    // Update is called once per frame
    void Update()
    {
        //Reduce time
        CountDown -= Time.deltaTime;

        //Restart Level if the time runs out
        if (CountDown <=0)
        {
            LevelManager load = GameObject.Find("LevelManager").GetComponent<LevelManager>();
            load.LoadLevel("Lose_Scene");
        }
    }

    private void OnGUI()
    {
        GUI.color = Color.yellow;
        var rightStyle = GUI.skin.GetStyle("Label");
        rightStyle.alignment = TextAnchor.UpperRight;
        rightStyle.fontSize = 20;
        GUI.Label(new Rect(Screen.width / 50, 0, 100, 50), "Time " + CountDown
          , rightStyle);
    }
}
