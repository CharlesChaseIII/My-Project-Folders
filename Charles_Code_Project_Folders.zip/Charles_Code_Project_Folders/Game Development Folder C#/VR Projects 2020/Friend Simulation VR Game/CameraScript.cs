﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour
{

    private const float Y_Angle_Min = 0.0f;

    private const float Y_Angle_Max = 100.0f;

    private const float X_Angle_Min = 0.0f;

    private const float X_Angle_Max = 50.0f;

    public Transform followPlayer;

    public Transform cameraTransform;

    private Camera cam;

    private float distance = 0.0f;

    private float currentX = 0.0f;

    private float currentY = 0.0f;



    // Start is called before the first frame update
    void Start()
    {
        cameraTransform = transform;

        //cam = Camera.main;
    }

    // Update is called once per frame
    void Update()
    {
        currentX += Input.GetAxis("Mouse X");

        currentY += Input.GetAxis("Mouse Y");

        currentY = Mathf.Clamp(currentY, Y_Angle_Min, Y_Angle_Max);

        currentX = Mathf.Clamp(currentX, X_Angle_Min, X_Angle_Max);

    }

    private void LateUpdate()
    {
        Vector3 dir = new Vector3(0, 0, -distance);

        Quaternion rotation = Quaternion.Euler(currentX, currentY, 0);

        cameraTransform.position = followPlayer.position + rotation * dir;

        cameraTransform.LookAt(followPlayer.position);
    }
}
