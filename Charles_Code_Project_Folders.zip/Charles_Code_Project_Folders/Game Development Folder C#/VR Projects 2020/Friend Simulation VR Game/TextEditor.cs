﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextEditor : MonoBehaviour
{
    [SerializeField] Text textComponent;

    [SerializeField] State startingState;

    //public Animator DialogueAnimator;
   // public Animator TextAnimator;

    public KeyCode AnyKey;

    //The current State
    State currentState;

    //private Queue<string> sentences;

    // Start is called before the first frame update
    void Start()
    {
        StartConversation();
    }

    // Update is called once per frame
    void Update()
    {
        ManageState();
    }

    public void StartConversation()
    {
        //DialogueAnimator.SetBool("FadeOut", true);
        //TextAnimator.SetBool("TextIn", true);
        //TextAnimator.SetBool("TextOut", false);

        // Tells you what state is currently assigned at the moment
        currentState = startingState;

        textComponent.text = currentState.GetStateStory();
    }

    public void ManageState()
    {
        var nextStates = currentState.GetNextStates();
        for (int index = 0; index < nextStates.Length; index++)
        {
            if (Input.GetKeyDown(AnyKey + index))
            {
                currentState = nextStates[index];
                
              
            }


        }


        /*if (Input.GetKeyDown(AnyKey))
        {
            currentState = nextStates[0];
        }
        else if (Input.GetKeyDown(AnyKey))
        {
            currentState = nextStates[1];
        }
        else if (Input.GetKeyDown(AnyKey))
        {
            currentState = nextStates[2];
        }*/

        textComponent.text = currentState.GetStateStory();
        
        
    }

    public void EndDialogue()
    {
        //DialogueAnimator.SetBool("FadeOut", false);
        //TextAnimator.SetBool("TextIn", false);
        //TextAnimator.SetBool("TextOut", true);
        
    }
}
