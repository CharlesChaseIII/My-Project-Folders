﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_Script : MonoBehaviour {

	PlayerControllerOne Player;

	// Use this for initialization
	void Start () {

		Player = FindObjectOfType<PlayerControllerOne>();
	}
	
	// Update is called once per frame
	void Update () {

		Vector2 newCamPos = new Vector2(Player.transform.position.x, Player.transform.position.y);

		transform.position = new Vector3(newCamPos.x, newCamPos.y, transform.position.z);
	}
}
