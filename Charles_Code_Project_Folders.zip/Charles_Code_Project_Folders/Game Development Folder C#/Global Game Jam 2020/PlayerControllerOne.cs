﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControllerOne : MonoBehaviour {

	public GameObject fist_Attack;

	public float playerSpeed;

	public float health;

	public float punch;

	public float jumpForce;

	public float Punch_Rate = 0.5f;

	public float punchSpeed = 11.0f;

	Rigidbody2D rB;

	Collider2D myCollider2D;

	// Use this for initialization
	void Start()
	{

		rB = GetComponent<Rigidbody2D>();

		myCollider2D = gameObject.GetComponent<Collider2D>();
	}

	// Update is called once per frame
	void Update()
	{

		PlayerMovement();

		Jump();

		FlipSprite();

		if (Input.GetButtonDown("Fire1"))
		{
			InvokeRepeating("Make_Punch_Fly", 0.0001f, Punch_Rate);
		}

		if (Input.GetButtonUp("Fire1"))
		{
			CancelInvoke("Make_Punch_Fly");
		}
	}

	void PlayerMovement()
	{

		float moveHorizontal = Input.GetAxis("Horizontal");

		Vector2 PlayerVelocity = new Vector2(moveHorizontal * playerSpeed, rB.velocity.y);

		rB.velocity = PlayerVelocity;

		bool PlayerHasHorizontalSpeed = Mathf.Abs(rB.velocity.x) > Mathf.Epsilon;

	}

	void Jump() {

		if (!myCollider2D.IsTouchingLayers(LayerMask.GetMask("Ground")))
		{

			return;
		}

		

		if (Input.GetButtonDown("Jump"))
		{

			Vector2 Add_Additional_JumpSpeed = new Vector2 (0f, jumpForce);

			rB.velocity += Add_Additional_JumpSpeed;

		}


	}


	void FlipSprite()
    {

		bool PlayerHasHorizontalSpeed = Mathf.Abs(rB.velocity.x) > Mathf.Epsilon;

		if (PlayerHasHorizontalSpeed)
        {

			transform.localScale = new Vector2 (Mathf.Sign(rB.velocity.x), -1f);

        }

    }

	void Make_Punch_Fly()
	{
		GameObject punch = Instantiate(fist_Attack, transform.position, Quaternion.identity) as GameObject;

		punch.GetComponent<Rigidbody2D>().velocity = new Vector3(punchSpeed, 2.8f, 0);

	}

	void OnCollisionEnter2D(Collision2D Collider)
	{
		PunchAttack Punch = Collider.gameObject.GetComponent<PunchAttack>();

		if (Punch)
        {
			Punch.Upon_Impact();

			health -= Punch.Damage();

			if (health <= 0)
            {
				Die();
            }
        }
    }

	void Die()
    {
		LevelManager lose = GameObject.Find("LevelManager").GetComponent<LevelManager>();
		lose.Loadlevel("Lose_Scene");
		Destroy(gameObject);
    }
}