﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PunchAttack : MonoBehaviour {

	public float health;

	public float damage;

	// Use this for initialization
	void Start () {
		
		

	}
	
	// Update is called once per frame
	void Update () {

		
	}

	float Health()
    {
		return health;
    }

	public float Damage()
    {
		return damage;
    }

	public void Upon_Impact()
    {
		Destroy(gameObject);
    }

	
}
